USE [Web_HRIS]
GO
/****** Object:  Table [dbo].[N_HRIS_Jenis_Approval]    Script Date: 15/01/2026 10:25:31 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[N_HRIS_Jenis_Approval](
	[Id_Jenis_Approval] [int] IDENTITY(1,1) NOT NULL,
	[Nama_Approval] [varchar](100) NOT NULL,
	[Source_Type] [varchar](50) NOT NULL,
	[Source_Reference] [varchar](100) NULL,
	[Auto_Approve] [char](1) NOT NULL,
	[Keterangan] [varchar](255) NULL,
	[Flag_Aktif] [char](1) NOT NULL,
	[Created_At] [datetime] NULL,
	[Created_By] [varchar](200) NULL,
	[Updated_At] [datetime] NULL,
	[Updated_By] [varchar](200) NULL,
PRIMARY KEY CLUSTERED 
(
	[Id_Jenis_Approval] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  View [dbo].[N_HRIS_VW_Approval_Request]    Script Date: 15/01/2026 10:25:31 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE VIEW [dbo].[N_HRIS_VW_Approval_Request] AS    
SELECT    
    req.id AS Id_Approval_Request,    
    req.No_Transaksi,    
    req.Kode_Karyawan AS Kode_Karyawan_Requester,    
    req.created_at AS Tanggal_Request,    
    req.Flag_Approval AS Flag_Approval,    
    req.Flow_Id,  
    
    
    -- Jika di tabel Request kosong, ambil dari Master Flow
    ISNULL(req.Request_Order_Flow, flow.order_flow) AS Request_Order_Flow,  
    
    CASE    
        WHEN req.Flag_Group = 'Y' THEN 'GROUP_FLOW'    
        WHEN req.Flow_Id IS NOT NULL THEN 'LEGACY_FLOW'    
        ELSE 'DIRECT'    
    END AS Tipe_Approval,    
    
    COALESCE(    
        req.Approver_Karyawan_Kode,    
        flow.Kode_Karyawan,    
        CASE    
            WHEN req.Flag_Group = 'Y' THEN CAST( ja.Nama_Approval AS VARCHAR)    
            ELSE NULL    
        END,    
        ja.Source_Reference    
    ) AS Current_Approver_Kode,    
    
    CASE    
        WHEN req.Flag_Group = 'Y' THEN req.Group_Reference_Id    
        ELSE NULL    
    END AS Target_Group_Id,    
    
    -- 2. LOGIKA STATUS ALUR (PERBAIKAN UTAMA DISINI)
    CASE    
        -- A. HISTORY: Jika sudah ada statusnya, selesai.
        WHEN req.Flag_Approval IS NOT NULL THEN 'HISTORY'    
        
        -- B. VOID: Cek step sebelumnya yang DITOLAK
        WHEN EXISTS (    
            SELECT 1    
            FROM dbo.HRIS_Approval_Request prev_req
            -- JOIN JUGA KE FLOW UNTUK DATA PREV
            LEFT JOIN dbo.HRIS_Approval_Flow prev_flow ON prev_req.Flow_Id = prev_flow.id
            WHERE    
                prev_req.No_Transaksi = req.No_Transaksi    
                
                -- BANDINGKAN NILAI YANG SUDAH DINORMALISASI (Request vs Request, atau Flow vs Flow)
                AND ISNULL(prev_req.Request_Order_Flow, prev_flow.order_flow) < ISNULL(req.Request_Order_Flow, flow.order_flow)
                
                AND prev_req.Flag_Approval = 'T'  
        ) THEN 'VOID'    
        
        -- C. FUTURE: Cek step sebelumnya yang MASIH PENDING
        WHEN EXISTS (    
            SELECT 1    
            FROM dbo.HRIS_Approval_Request prev_req
            LEFT JOIN dbo.HRIS_Approval_Flow prev_flow ON prev_req.Flow_Id = prev_flow.id
            WHERE    
                prev_req.No_Transaksi = req.No_Transaksi
                
                -- BANDINGKAN NILAI YANG SUDAH DINORMALISASI
                AND ISNULL(prev_req.Request_Order_Flow, prev_flow.order_flow) < ISNULL(req.Request_Order_Flow, flow.order_flow)
                
                AND prev_req.Flag_Approval IS NULL    
        ) THEN 'FUTURE'    
        
        -- D. CURRENT
        ELSE 'CURRENT'    
    END AS Flow_State,    
    
    req.Approved_By_Kode AS Approved_By,    
    req.Catatan,    
    CASE    
        WHEN req.Flag_Approval IS NOT NULL THEN req.update_at    
        ELSE NULL    
    END AS Tanggal_Approved    

FROM    
    dbo.HRIS_Approval_Request req    
    LEFT JOIN dbo.HRIS_Approval_Flow flow ON req.Flow_Id = flow.id    
    LEFT JOIN dbo.N_HRIS_Jenis_Approval ja ON ja.Id_Jenis_Approval = req.Id_Jenis_Approval;
GO
/****** Object:  Table [dbo].[Transaksi_Cuti]    Script Date: 15/01/2026 10:25:31 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Transaksi_Cuti](
	[Kode_Perusahaan] [varchar](3) NOT NULL,
	[No_Transaksi] [varchar](30) NOT NULL,
	[Tanggal] [datetime] NULL,
	[Jam] [varchar](8) NULL,
	[Status] [char](1) NULL,
	[UserID] [varchar](15) NULL,
	[Updated_At] [datetime] NULL,
	[Updated_By] [int] NULL,
	[Flag_Cancelled_By_Admin] [char](1) NULL,
PRIMARY KEY CLUSTERED 
(
	[No_Transaksi] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Transaksi_Cuti_Det]    Script Date: 15/01/2026 10:25:31 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Transaksi_Cuti_Det](
	[Kode_Perusahaan] [varchar](3) NOT NULL,
	[No_Transaksi] [varchar](30) NOT NULL,
	[Kode_Karyawan] [varchar](50) NOT NULL,
	[Urut_Detail] [int] NOT NULL,
	[Tanggal_Cuti] [datetime] NOT NULL,
	[Urut_Oto] [int] IDENTITY(1,1) NOT NULL,
	[Jenis_Tanggal_Pengajuan] [varchar](30) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Transaksi_Cuti_Detail]    Script Date: 15/01/2026 10:25:31 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Transaksi_Cuti_Detail](
	[Kode_Perusahaan] [varchar](3) NOT NULL,
	[No_Transaksi] [varchar](30) NOT NULL,
	[Kode_Karyawan] [varchar](50) NOT NULL,
	[Jenis] [varchar](20) NOT NULL,
	[Tanggal_Cuti_Dari] [datetime] NULL,
	[Tanggal_Cuti_Sampai] [datetime] NULL,
	[Alasan] [varchar](100) NULL,
	[Urut_Oto] [int] IDENTITY(1,1) NOT NULL,
	[filePath] [varchar](100) NULL,
	[Flag_Approval] [char](1) NULL,
	[Id_Jenis_Cuti] [int] NULL,
 CONSTRAINT [PK__Transaks__3A5E7949C64FFD54] PRIMARY KEY CLUSTERED 
(
	[No_Transaksi] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[N_HRIS_Cuti_Bersama]    Script Date: 15/01/2026 10:25:31 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[N_HRIS_Cuti_Bersama](
	[Id_Cuti_Bersama] [int] IDENTITY(1,1) NOT NULL,
	[Nama_Cuti_Bersama] [varchar](100) NULL,
	[Tanggal_Mulai] [date] NULL,
	[Tanggal_Selesai] [date] NULL,
	[Jumlah_Hari] [decimal](5, 2) NULL,
	[Potong_Ke_Tipe_Cuti] [varchar](20) NULL,
	[Flag_Aktif] [char](1) NOT NULL,
	[Created_At] [datetime] NULL,
	[Created_By] [varchar](200) NULL,
	[Updated_At] [datetime] NULL,
	[Updated_By] [varchar](200) NULL,
PRIMARY KEY CLUSTERED 
(
	[Id_Cuti_Bersama] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[N_HRIS_Jenis_Cuti]    Script Date: 15/01/2026 10:25:31 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[N_HRIS_Jenis_Cuti](
	[Id_Jenis_Cuti] [int] IDENTITY(1,1) NOT NULL,
	[Nama_Jenis_Cuti] [varchar](100) NOT NULL,
	[Deskripsi] [varchar](255) NULL,
	[Kuota_Default] [int] NOT NULL,
	[Satuan] [varchar](10) NOT NULL,
	[Masa_Berlaku_Bulan] [int] NULL,
	[Dapat_Diakumulasi] [char](1) NULL,
	[Gender_Spesifik] [varchar](10) NULL,
	[Minimal_Masa_Kerja_Bulan] [int] NULL,
	[Maksimum_Pengajuan] [int] NOT NULL,
	[Perlu_Persetujuan_Khusus] [char](1) NOT NULL,
	[Dokumen_Pendukung] [char](1) NOT NULL,
	[Flag_Aktif] [char](1) NOT NULL,
	[Created_At] [datetime] NOT NULL,
	[Created_By] [varchar](50) NOT NULL,
	[Updated_At] [datetime] NULL,
	[Updated_By] [varchar](50) NULL,
	[Memotong_Saldo_Cuti] [char](1) NULL,
	[Format_Tanggal_Select] [varchar](20) NULL,
	[Batas_Hari_Pengajuan] [int] NULL,
	[Flag_Bisa_Hutang_Cuti] [char](1) NULL,
PRIMARY KEY CLUSTERED 
(
	[Id_Jenis_Cuti] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  View [dbo].[N_HRIS_VW_Saldo_Cuti_Karyawan]    Script Date: 15/01/2026 10:25:31 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE   VIEW [dbo].[N_HRIS_VW_Saldo_Cuti_Karyawan] AS 
	WITH 
Saldo_Fisik AS (
    SELECT 
        Kode_Karyawan,
        SUM(sisa_cuti) AS Total_Saldo_DB
    FROM dbo.HRIS_Buku_Cuti
    WHERE 
        Flag_Aktif = 'Y' 
        AND Id_Jenis_Cuti IN (1, 2) -- (1=Tahunan, 2=Loyalty)
        
        AND (
            (tanggal_expired >= CAST(GETDATE() AS DATE) AND Activated_At <= CAST(GETDATE() AS DATE))
            OR sisa_cuti < 0 
        )
    GROUP BY Kode_Karyawan
),
Pending_Booking AS (
    SELECT
        a.Kode_Karyawan,
        COUNT(a.Tanggal_Cuti) AS Total_Hari_Pending
    FROM
        dbo.Transaksi_Cuti_Det a
        INNER JOIN dbo.Transaksi_Cuti b ON a.No_Transaksi = b.No_Transaksi
        INNER JOIN dbo.Transaksi_Cuti_Detail c ON a.No_Transaksi = c.No_Transaksi
        INNER JOIN dbo.N_HRIS_Jenis_Cuti jc ON c.Id_Jenis_Cuti = jc.Id_Jenis_Cuti
    WHERE
        jc.Memotong_Saldo_Cuti = 'Y'
        AND c.Flag_Approval IS NULL
        AND b.Status IS NULL
    GROUP BY
        a.Kode_Karyawan
),
Cuti_Bersama_Future AS (
    SELECT ISNULL(SUM(Jumlah_Hari), 0) AS Total_Potongan_CB
    FROM
        dbo.N_HRIS_Cuti_Bersama
    WHERE
        Flag_Aktif = 'Y'
        AND Tanggal_Selesai >= CAST(GETDATE() AS DATE) 
		--AND Flag_Eksekusi = 'N'
)
SELECT
    k.Kode_Karyawan,
    k.Nama AS Nama_Karyawan,
    ISNULL(sf.Total_Saldo_DB, 0) AS Saldo_Awal_DB,
    ISNULL(pb.Total_Hari_Pending, 0) AS Sedang_Diajukan,
    (
        SELECT
            Total_Potongan_CB
        FROM
            Cuti_Bersama_Future
    ) AS Potongan_Cuti_Bersama,
    -- Rumus: MAX(Total - Pending - CB, 0) 
	CASE
        WHEN (
            ISNULL(sf.Total_Saldo_DB, 0) - ISNULL(pb.Total_Hari_Pending, 0) - (
                SELECT
                    Total_Potongan_CB
                FROM
                    Cuti_Bersama_Future
            )
        ) > 0 THEN (
            ISNULL(sf.Total_Saldo_DB, 0) - ISNULL(pb.Total_Hari_Pending, 0) - (
                SELECT
                    Total_Potongan_CB
                FROM
                    Cuti_Bersama_Future
            )
        )
        ELSE 0
    END AS Sisa_Cuti_Tampil,
    -- Rumus: ABS(MIN(Total - Pending - CB, 0)) 
	CASE
        WHEN (
            ISNULL(sf.Total_Saldo_DB, 0) - ISNULL(pb.Total_Hari_Pending, 0) - (
                SELECT
                    Total_Potongan_CB
                FROM
                    Cuti_Bersama_Future
            )
        ) < 0 THEN ABS(
            ISNULL(sf.Total_Saldo_DB, 0) - ISNULL(pb.Total_Hari_Pending, 0) - (
                SELECT
                    Total_Potongan_CB
                FROM
                    Cuti_Bersama_Future
            )
        )
        ELSE 0
    END AS Hutang_Cuti_Tampil
FROM
    dbo.Karyawan k
    LEFT JOIN Saldo_Fisik sf ON k.Kode_Karyawan = sf.Kode_Karyawan
    LEFT JOIN Pending_Booking pb ON k.Kode_Karyawan = pb.Kode_Karyawan
WHERE
    k.Tanggal_Resign IS NULL;-- Hanya Karyawan Aktif
GO
/****** Object:  Table [dbo].[N_HRIS_Cuti_Approval]    Script Date: 15/01/2026 10:25:31 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[N_HRIS_Cuti_Approval](
	[Id_Cuti_Approval] [int] IDENTITY(1,1) NOT NULL,
	[Id_Jenis_Cuti] [int] NOT NULL,
	[Id_Jenis_Approval] [int] NOT NULL,
	[Order_Flow] [int] NOT NULL,
	[Flag_Aktif] [char](1) NOT NULL,
	[Created_At] [datetime] NULL,
	[Created_By] [varchar](200) NULL,
	[Updated_At] [datetime] NULL,
	[Updated_By] [varchar](200) NULL,
PRIMARY KEY CLUSTERED 
(
	[Id_Cuti_Approval] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[N_HRIS_HC_Approval]    Script Date: 15/01/2026 10:25:31 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[N_HRIS_HC_Approval](
	[Id_HC_Approval] [int] IDENTITY(1,1) NOT NULL,
	[Kode_Karyawan_Approver] [varchar](200) NOT NULL,
	[Flag_Aktif] [char](1) NOT NULL,
	[Created_At] [datetime] NULL,
	[Created_By] [varchar](200) NULL,
	[Updated_At] [datetime] NULL,
	[Updated_By] [varchar](200) NULL,
	[Group_Id] [int] NULL,
	[Keterangan] [text] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id_HC_Approval] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[N_HRIS_Log_Buku_Cuti]    Script Date: 15/01/2026 10:25:31 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[N_HRIS_Log_Buku_Cuti](
	[Id_Log] [bigint] IDENTITY(1,1) NOT NULL,
	[Id_Buku_Cuti] [int] NOT NULL,
	[No_Transaksi_Ref] [varchar](50) NULL,
	[Jenis_Mutasi] [varchar](10) NOT NULL,
	[Kategori_Transaksi] [varchar](50) NOT NULL,
	[Jumlah] [decimal](5, 2) NOT NULL,
	[Saldo_Sebelum] [decimal](5, 2) NULL,
	[Saldo_Sesudah] [decimal](5, 2) NULL,
	[Keterangan] [text] NULL,
	[Created_At] [datetime] NULL,
	[Created_By] [varchar](100) NULL,
PRIMARY KEY CLUSTERED 
(
	[Id_Log] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
ALTER TABLE [dbo].[N_HRIS_Cuti_Approval] ADD  DEFAULT (getdate()) FOR [Created_At]
GO
ALTER TABLE [dbo].[N_HRIS_Cuti_Bersama] ADD  DEFAULT ('T') FOR [Flag_Aktif]
GO
ALTER TABLE [dbo].[N_HRIS_Cuti_Bersama] ADD  DEFAULT (getdate()) FOR [Created_At]
GO
ALTER TABLE [dbo].[N_HRIS_HC_Approval] ADD  DEFAULT ('T') FOR [Flag_Aktif]
GO
ALTER TABLE [dbo].[N_HRIS_HC_Approval] ADD  DEFAULT (getdate()) FOR [Created_At]
GO
ALTER TABLE [dbo].[N_HRIS_Jenis_Approval] ADD  DEFAULT ('T') FOR [Auto_Approve]
GO
ALTER TABLE [dbo].[N_HRIS_Jenis_Approval] ADD  DEFAULT ('T') FOR [Flag_Aktif]
GO
ALTER TABLE [dbo].[N_HRIS_Jenis_Approval] ADD  DEFAULT (getdate()) FOR [Created_At]
GO
ALTER TABLE [dbo].[N_HRIS_Jenis_Cuti] ADD  DEFAULT ((0)) FOR [Kuota_Default]
GO
ALTER TABLE [dbo].[N_HRIS_Jenis_Cuti] ADD  DEFAULT ('hari') FOR [Satuan]
GO
ALTER TABLE [dbo].[N_HRIS_Jenis_Cuti] ADD  DEFAULT ((12)) FOR [Masa_Berlaku_Bulan]
GO
ALTER TABLE [dbo].[N_HRIS_Jenis_Cuti] ADD  DEFAULT ('T') FOR [Dapat_Diakumulasi]
GO
ALTER TABLE [dbo].[N_HRIS_Jenis_Cuti] ADD  DEFAULT (NULL) FOR [Gender_Spesifik]
GO
ALTER TABLE [dbo].[N_HRIS_Jenis_Cuti] ADD  DEFAULT (NULL) FOR [Minimal_Masa_Kerja_Bulan]
GO
ALTER TABLE [dbo].[N_HRIS_Jenis_Cuti] ADD  DEFAULT ('T') FOR [Perlu_Persetujuan_Khusus]
GO
ALTER TABLE [dbo].[N_HRIS_Jenis_Cuti] ADD  DEFAULT ('T') FOR [Dokumen_Pendukung]
GO
ALTER TABLE [dbo].[N_HRIS_Jenis_Cuti] ADD  DEFAULT ('T') FOR [Flag_Aktif]
GO
ALTER TABLE [dbo].[N_HRIS_Jenis_Cuti] ADD  DEFAULT (getdate()) FOR [Created_At]
GO
ALTER TABLE [dbo].[N_HRIS_Jenis_Cuti] ADD  DEFAULT ('MULTIPLE') FOR [Format_Tanggal_Select]
GO
ALTER TABLE [dbo].[N_HRIS_Log_Buku_Cuti] ADD  DEFAULT (getdate()) FOR [Created_At]
GO
ALTER TABLE [dbo].[Transaksi_Cuti_Det] ADD  DEFAULT ('MULTIPLE') FOR [Jenis_Tanggal_Pengajuan]
GO
ALTER TABLE [dbo].[N_HRIS_Log_Buku_Cuti]  WITH CHECK ADD FOREIGN KEY([Id_Buku_Cuti])
REFERENCES [dbo].[HRIS_Buku_Cuti] ([Id_Buku_Cuti])
GO
ALTER TABLE [dbo].[N_HRIS_Jenis_Cuti]  WITH CHECK ADD CHECK  (([Format_Tanggal_Select]='RANGE' OR [Format_Tanggal_Select]='MULTIPLE'))
GO
ALTER TABLE [dbo].[N_HRIS_Log_Buku_Cuti]  WITH CHECK ADD CHECK  (([Jenis_Mutasi]='DEBIT' OR [Jenis_Mutasi]='CREDIT'))
GO
