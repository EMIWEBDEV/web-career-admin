CREATE TABLE N_WEB_CAREERS_Klasifikasi_Akun (
    Id_Klasifikasi_Akun int IDENTITY(1,1) NOT NULL PRIMARY KEY,
    Kode varchar(30) NOT NULL UNIQUE,
    Nama varchar(100) NOT NULL,
    Durasi_Hari int NULL,
    Is_Default_Register char(1) NOT NULL DEFAULT 'N' CHECK (Is_Default_Register IN ('Y','N')),
    Flag_Aktif char(1) NOT NULL DEFAULT 'Y' CHECK (Flag_Aktif IN ('Y','N')),
    Created_At datetime NULL,
    Created_By varchar(200) NULL,
    Updated_At datetime NULL,
    Updated_By varchar(200) NULL
);
GO

INSERT INTO N_WEB_CAREERS_Klasifikasi_Akun (Kode, Nama, Durasi_Hari, Is_Default_Register, Flag_Aktif, Created_At, Created_By, Updated_At, Updated_By) VALUES
(N'PERMANEN', N'Akun Permanen', NULL, 'N', 'Y', GETDATE(), 'SYSTEM', GETDATE(), 'SYSTEM'),
(N'TRIAL_3_MINGGU', N'Trial 3 Minggu', 21, 'N', 'Y', GETDATE(), 'SYSTEM', GETDATE(), 'SYSTEM'),
(N'TRIAL_6_BULAN', N'Trial 6 Bulan', 180, 'Y', 'Y', GETDATE(), 'SYSTEM', GETDATE(), 'SYSTEM');
GO
