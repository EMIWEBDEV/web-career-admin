CREATE TABLE N_WEB_CAREERS_Users (
    Id_Users int IDENTITY(1,1) NOT NULL PRIMARY KEY,
    Nama varchar(150) NOT NULL,
    Email varchar(150) NOT NULL UNIQUE,
    No_Hp varchar(30) NULL,
    Password varchar(255) NOT NULL,
    Role varchar(20) NOT NULL DEFAULT 'KANDIDAT' CHECK (Role IN ('ADMIN','KANDIDAT')),
    Klasifikasi varchar(20) NOT NULL DEFAULT 'PERMANEN' CHECK (Klasifikasi IN ('PERMANEN','TRIAL_3_BULAN','TRIAL_6_BULAN')),
    Status varchar(15) NOT NULL DEFAULT 'AKTIF' CHECK (Status IN ('AKTIF','NONAKTIF')),
    Mulai_Berlaku date NOT NULL DEFAULT (CAST(GETDATE() AS date)),
    Valid_Until date NULL,
    Email_Verified_At datetime NULL,
    Last_Login_At datetime NULL,
    Created_At datetime NULL,
    Created_By varchar(200) NULL,
    Updated_At datetime NULL,
    Updated_By varchar(200) NULL
);
GO

INSERT INTO N_WEB_CAREERS_Users (Nama, Email, No_Hp, Password, Role, Klasifikasi, Status, Mulai_Berlaku, Valid_Until, Email_Verified_At, Created_At, Created_By, Updated_At, Updated_By) VALUES
(N'Admin Rekrutmen', N'admin@evonusabersaudara.co.id', N'0811-2000-0001', N'$2y$10$UIkEKxa1VUFS9Urhglfs/OZWSl9bFoRZQ/FJi4WiW2qED0.zzxJgO', 'ADMIN', 'PERMANEN', 'AKTIF', CAST(GETDATE() AS date), NULL, GETDATE(), GETDATE(), 'SYSTEM', GETDATE(), 'SYSTEM'),
(N'HR Manager', N'hr.manager@evonusabersaudara.co.id', N'0811-2000-0002', N'$2y$10$UIkEKxa1VUFS9Urhglfs/OZWSl9bFoRZQ/FJi4WiW2qED0.zzxJgO', 'ADMIN', 'PERMANEN', 'AKTIF', CAST(GETDATE() AS date), NULL, GETDATE(), GETDATE(), 'SYSTEM', GETDATE(), 'SYSTEM'),
(N'Budi Santoso', N'budi.santoso@email.com', N'0812-3456-7890', N'$2y$10$UIkEKxa1VUFS9Urhglfs/OZWSl9bFoRZQ/FJi4WiW2qED0.zzxJgO', 'KANDIDAT', 'PERMANEN', 'AKTIF', CAST(GETDATE() AS date), NULL, GETDATE(), GETDATE(), 'SYSTEM', GETDATE(), 'SYSTEM'),
(N'Citra Dewi', N'citra.dewi@email.com', N'0813-1111-2222', N'$2y$10$UIkEKxa1VUFS9Urhglfs/OZWSl9bFoRZQ/FJi4WiW2qED0.zzxJgO', 'KANDIDAT', 'PERMANEN', 'AKTIF', CAST(GETDATE() AS date), NULL, GETDATE(), GETDATE(), 'SYSTEM', GETDATE(), 'SYSTEM'),
(N'Kandidat Trial 3 Bulan Valid', N'trial3.aktif@email.com', N'0814-3333-4444', N'$2y$10$UIkEKxa1VUFS9Urhglfs/OZWSl9bFoRZQ/FJi4WiW2qED0.zzxJgO', 'KANDIDAT', 'TRIAL_3_BULAN', 'AKTIF', DATEADD(MONTH, -1, CAST(GETDATE() AS date)), DATEADD(MONTH, 2, CAST(GETDATE() AS date)), GETDATE(), GETDATE(), 'SYSTEM', GETDATE(), 'SYSTEM'),
(N'Kandidat Trial 3 Bulan Kedaluwarsa', N'trial3.kadaluarsa@email.com', N'0815-5555-6666', N'$2y$10$UIkEKxa1VUFS9Urhglfs/OZWSl9bFoRZQ/FJi4WiW2qED0.zzxJgO', 'KANDIDAT', 'TRIAL_3_BULAN', 'AKTIF', DATEADD(MONTH, -5, CAST(GETDATE() AS date)), DATEADD(MONTH, -2, CAST(GETDATE() AS date)), GETDATE(), GETDATE(), 'SYSTEM', GETDATE(), 'SYSTEM'),
(N'Kandidat Trial 6 Bulan Valid', N'trial6.aktif@email.com', N'0816-7777-8888', N'$2y$10$UIkEKxa1VUFS9Urhglfs/OZWSl9bFoRZQ/FJi4WiW2qED0.zzxJgO', 'KANDIDAT', 'TRIAL_6_BULAN', 'AKTIF', DATEADD(MONTH, -2, CAST(GETDATE() AS date)), DATEADD(MONTH, 4, CAST(GETDATE() AS date)), GETDATE(), GETDATE(), 'SYSTEM', GETDATE(), 'SYSTEM'),
(N'Kandidat Trial 6 Bulan Kedaluwarsa', N'trial6.kadaluarsa@email.com', N'0817-9999-0000', N'$2y$10$UIkEKxa1VUFS9Urhglfs/OZWSl9bFoRZQ/FJi4WiW2qED0.zzxJgO', 'KANDIDAT', 'TRIAL_6_BULAN', 'AKTIF', DATEADD(MONTH, -8, CAST(GETDATE() AS date)), DATEADD(MONTH, -2, CAST(GETDATE() AS date)), GETDATE(), GETDATE(), 'SYSTEM', GETDATE(), 'SYSTEM'),
(N'Kandidat Nonaktif', N'nonaktif@email.com', N'0818-1212-3434', N'$2y$10$UIkEKxa1VUFS9Urhglfs/OZWSl9bFoRZQ/FJi4WiW2qED0.zzxJgO', 'KANDIDAT', 'PERMANEN', 'NONAKTIF', CAST(GETDATE() AS date), NULL, GETDATE(), GETDATE(), 'SYSTEM', GETDATE(), 'SYSTEM');
GO
